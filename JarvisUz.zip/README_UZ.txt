A) AI SERVER (bir marta, telefon brauzerida):
 1. dash.cloudflare.com -> bepul akkaunt -> Workers -> "Create Worker" -> worker/worker.js ichidagi kodni qo'ying -> Deploy.
 2. Settings -> Variables and Secrets: GEMINI_KEY (aistudio.google.com dan olingan kalit) va APP_TOKEN (o'zingiz o'ylab topgan uzun parol).
 3. Worker manzilini (https://....workers.dev) ilovaning "Sozlamalar" qismiga, APP_TOKEN bilan birga kiriting.
B) APK OLISH (kompyutersiz):
 1. github.com da akkaunt -> New repository (JarvisUz).
 2. ZIP'ni Fayllar ilovasida oching; "Add file > Upload files" orqali hamma papkalarni (.github ham) yuklang.
 3. Actions -> "APK yig'ish" -> Run workflow. 5-8 daqiqa.
 4. Tugagach "JarvisUz-APK" ni yuklab oling, ZIP'dan app-release.apk ni o'rnating.
C) ILK SOZLASH: Mikrofon ruxsati, Maxsus imkoniyatlarda JARVIS UZ ni yoqish, "Ustida ko'rsatish" ruxsati, Ilovalarim'da kerakli ilovalarga ruxsat, batareya sozlamalarida JARVIS UZ ni "Cheklovsiz" qilish.
