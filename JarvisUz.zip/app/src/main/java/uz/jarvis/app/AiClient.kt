package uz.jarvis.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** API kalit APK ichida EMAS: u faqat sizning serveringizda (worker/worker.js) saqlanadi. */
object AiClient {
    fun ask(proxyUrl: String, token: String, history: List<Pair<String, String>>): String {
        val arr = JSONArray()
        history.forEach { arr.put(JSONObject().put("role", it.first).put("text", it.second)) }
        val c = URL(proxyUrl).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 40000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("X-App-Token", token); c.doOutput = true
        c.outputStream.use { it.write(JSONObject().put("messages", arr).toString().toByteArray()) }
        if (c.responseCode !in 200..299) error("Server xatosi: ${c.responseCode}")
        return JSONObject(c.inputStream.bufferedReader().readText()).getString("reply")
    }
}
