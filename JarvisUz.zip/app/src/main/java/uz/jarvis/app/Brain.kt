package uz.jarvis.app

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.Settings
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.*

/** Telefon buyruqlari. handle() true qaytarsa, buyruq tanildi va bajarildi (yoki sababi aytildi). */
class Brain(private val ctx: Context, private val say: (String) -> Unit) {
    companion object {
        val WAKE = Regex("(jarvis|jarvish|zharvis|charvis|yarvis|жарвис|джарвис|ярвис|жарвиз)", RegexOption.IGNORE_CASE)
        fun clean(s: String) = s.lowercase().replace("‘", "'").replace("’", "'").replace("ʻ", "'").replace("`", "'")
            .replace("o'", "o").replace("g'", "g").replace(Regex("[.,!?]"), " ").replace(Regex("\\s+"), " ").trim()
        fun norm(s: String) = clean(s).replace(WAKE, "").trim()
    }
    private val prefs = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private fun acc() = JarvisAccessibilityService.instance
    private fun needAcc(): Boolean { if (acc() == null) { say("Buning uchun Maxsus imkoniyatlarda JARVIS UZ ni yoqing."); return true }; return false }
    private fun start(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun handle(raw: String): Boolean {
        val t = norm(raw)
        when {
            "fonar" in t -> if ("ochir" in t || "uchir" in t) torch(false) else torch(true)
            "ovoz" in t && "pas" in t -> volume(false)
            "ovoz" in t && ("oshir" in t || "balandlig" in t || "kuchay" in t) -> volume(true)
            "skrinshot" in t -> { if (!needAcc()) say(if (acc()!!.screenshot()) "Skrinshot olindi." else "Skrinshot olib bo'lmadi.") }
            "bosh ekran" in t -> { if (!needAcc()) say(if (acc()!!.home()) "Bosh ekranga qaytdim." else "Bajarilmadi.") }
            t.startsWith("orqaga") -> { if (!needAcc()) say(if (acc()!!.back()) "Orqaga qaytdim." else "Bajarilmadi.") }
            "pastga" in t -> { if (!needAcc()) say(if (acc()!!.scroll(true)) "Pastga tushirdim." else "Bu ekranda aylantirib bo'lmadi.") }
            "tepaga" in t || "yuqoriga" in t -> { if (!needAcc()) say(if (acc()!!.scroll(false)) "Tepaga chiqardim." else "Bu ekranda aylantirib bo'lmadi.") }
            t.startsWith("bos ") -> { if (!needAcc()) { val n = t.removePrefix("bos ").trim(); say(if (acc()!!.clickByText(n)) "$n bosildi." else "$n yozuvli tugma topilmadi.") } }
            "batareya" in t -> { val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager; say("Batareya ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} foiz.") }
            "soat nech" in t || "vaqt" in t || "bugun sana" in t || "sana nech" in t -> say("Hozir " + SimpleDateFormat("HH:mm, d-MMMM", Locale.US).format(Date()))
            "hisobot" in t -> { val n = (prefs.getString("log", "") ?: "").lines().count { it.contains("JARVIS:") }; say("So'nggi tarixda $n ta javob va amal bor. Ekranda ko'rishingiz mumkin.") }
            "yuklab" in t && "fayl" in t -> try { start(Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS)); say("Yuklanganlar ochildi.") } catch (e: Exception) { say("Ochib bo'lmadi.") }
            "wifi" in t || "wi-fi" in t || "vay fay" in t -> { start(Intent(Settings.ACTION_WIFI_SETTINGS)); say("Wi-Fi sozlamalari ochildi.") }
            "bluetooth" in t -> { start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); say("Bluetooth sozlamalari ochildi.") }
            "sozlama" in t -> { start(Intent(Settings.ACTION_SETTINGS)); say("Sozlamalar ochildi.") }
            "kamera" in t -> try { start(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); say("Kamera ochildi.") } catch (e: Exception) { say("Kamerani ocha olmadim.") }
            "yutub" in t || "youtube" in t -> youtube(t)
            "toxtat" in t -> media(KeyEvent.KEYCODE_MEDIA_PAUSE, "To'xtatdim.")
            "davom" in t -> media(KeyEvent.KEYCODE_MEDIA_PLAY, "Davom ettiryapman.")
            "qongiroq" in t -> { start(Intent(Intent.ACTION_DIAL)); say("Raqam terish oynasi ochildi. Qo'ng'iroqni o'zingiz tasdiqlang.") }
            t.endsWith(" och") -> openByLabel(t.removeSuffix("och").trim().removeSuffix("ni").trim())
            else -> return false
        }
        return true
    }

    private fun torch(on: Boolean) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            cm.setTorchMode(id, on); say(if (on) "Fonar yoqildi." else "Fonar o'chirildi.")
        } catch (e: Exception) { say("Fonarni boshqara olmadim.") }
    }
    private fun volume(up: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        say(if (up) "Ovoz oshirildi." else "Ovoz pasaytirildi.")
    }
    private fun media(code: Int, msg: String) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code)); say(msg)
    }
    private fun allowed(): Set<String> = prefs.getStringSet("allowed", emptySet())!!
    private fun openByLabel(name: String) {
        if (name.isBlank()) { say("Qaysi ilovani ochay?"); return }
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = ctx.packageManager.queryIntentActivities(i, 0).map { it.loadLabel(ctx.packageManager).toString() to it.activityInfo.packageName }
        val hit = apps.firstOrNull { clean(it.first).contains(name) || name.contains(clean(it.first)) }
        if (hit == null) { say("Bunday ilova topilmadi."); return }
        if (hit.second !in allowed()) { say("${hit.first} uchun ruxsat berilmagan. Ilovalarim bo'limidan ruxsat bering."); return }
        try { start(ctx.packageManager.getLaunchIntentForPackage(hit.second)!!); say("${hit.first} ochildi.") }
        catch (e: Exception) { say("${hit.first} ni ocha olmadim. Android fonda ilova ochishni cheklagan bo'lishi mumkin.") }
    }
    private fun youtube(t: String) {
        val yt = "com.google.android.youtube"
        if (yt !in allowed()) { say("YouTube uchun ruxsat berilmagan. Ilovalarim bo'limidan ruxsat bering."); return }
        val q = t.replace("youtubeda", "").replace("yutubda", "").replace("youtube", "").replace("yutub", "")
            .replace("topib qoy", "").replace("top va qoy", "").replace("qoy", "").replace(Regex("\\boch\\b"), "").trim()
        try {
            if (q.isEmpty()) start(ctx.packageManager.getLaunchIntentForPackage(yt)!!)
            else start(Intent(Intent.ACTION_SEARCH).setPackage(yt).putExtra("query", q))
            say(if (q.isEmpty()) "YouTube ochildi." else "YouTube'da $q qidirildi.")
        } catch (e: Exception) { say("YouTube'ni ocha olmadim.") }
    }
}
