package uz.jarvis.app

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.text.SimpleDateFormat
import java.util.*

/** Uzluksiz suhbat: "JARVIS" deb chaqirilsa faollashadi, har savoldan keyin qayta eshitadi. */
class LiveService : Service(), TextToSpeech.OnInitListener {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var brain: Brain
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    @Volatile private var speaking = false
    private var lastSpoken = ""; private var lastSpokeAt = 0L
    private var rec: SpeechRecognizer? = null
    private var running = false
    private var conv = false
    private val history = ArrayList<Pair<String, String>>()
    private val stopRe = Regex("\\b(toxta|tuxta|stop|bas qil)\\b")
    private val timeout = Runnable { if (conv) { if (speaking) armTimeout() else { conv = false; history.clear(); note("Suhbat vaqti tugadi. \"JARVIS\" deb chaqiring.") } } }

    override fun onCreate() {
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        brain = Brain(this) { speak(it) }
        tts = TextToSpeech(this, this)
    }
    override fun onInit(s: Int) {
        if (s != TextToSpeech.SUCCESS) { note("Ovoz motori (TTS) ishga tushmadi."); return }
        val r = tts!!.setLanguage(Locale("uz", "UZ"))
        ttsOk = true
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts!!.language = Locale("tr", "TR"); note("O'zbek ovozi yo'q — turkcha ovoz ishlatilmoqda. Google TTS'dan o'zbek tilini yuklang.")
        }
        tts!!.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true }
            override fun onDone(id: String?) { speaking = false; lastSpokeAt = System.currentTimeMillis() }
            @Deprecated("x") override fun onError(id: String?) { speaking = false; lastSpokeAt = System.currentTimeMillis() }
            override fun onStop(id: String?, interrupted: Boolean) { speaking = false; lastSpokeAt = System.currentTimeMillis() }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        foreground()
        if (intent?.action == "TEXT") { intent.getStringExtra("t")?.let { process(it) }; return START_NOT_STICKY }
        if (!running) { running = true; prefs.edit().putBoolean("live", true).apply(); note("Tinglash boshlandi. \"JARVIS\" deb chaqiring."); listen() }
        return START_NOT_STICKY
    }
    private fun foreground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "JARVIS", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, LiveService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "jarvis").setContentTitle("JARVIS UZ eshitmoqda").setContentText("\"JARVIS\" deb chaqiring")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).addAction(Notification.Action.Builder(0, "To'xtatish", stop).build()).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
    }

    private fun listen() {
        if (!running) return
        rec?.destroy(); rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec!!.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard(it) }
                h.postDelayed({ listen() }, 250)
            }
            override fun onError(e: Int) {
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { note("Mikrofon ruxsati yo'q."); stopSelf(); return }
                h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 300)
            }
            override fun onPartialResults(p: Bundle?) {
                val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                // Barge-in: JARVIS gapirayotganda siz gapirsangiz, u to'xtaydi (o'z ovozining aks-sadosi hisoblanmaydi)
                if (speaking && t.trim().split(" ").size >= 2 && !Brain.clean(lastSpoken).contains(Brain.clean(t))) { tts?.stop(); speaking = false; note("(gapingiz bo'lindi)") }
            }
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onEvent(t: Int, p: Bundle?) {}
        })
        rec!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ"); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        })
    }

    private fun isEcho(c: String): Boolean =
        c.length > 3 && (speaking || System.currentTimeMillis() - lastSpokeAt < 2500) && Brain.clean(lastSpoken).contains(c)

    private fun heard(text: String) {
        val c = Brain.clean(text)
        if (c.isBlank() || isEcho(c)) return
        val hasWake = Brain.WAKE.containsMatchIn(c)
        if (stopRe.containsMatchIn(c) && (hasWake || (conv && c.split(" ").size <= 2))) {
            tts?.stop(); speaking = false; conv = false; history.clear(); h.removeCallbacks(timeout)
            speak("Suhbat to'xtadi. Chaqirsangiz, shu yerdaman."); return
        }
        val rest = text.replace(Brain.WAKE, "").trim(' ', ',', '.', '!')
        if (!conv) {
            if (!hasWake) return
            conv = true; armTimeout()
            if (rest.length < 2) speak("Eshitaman.") else process(rest)
            return
        }
        process(if (rest.isBlank()) text else rest)
    }

    private fun process(t: String) {
        armTimeout(); note("Siz: $t")
        if (brain.handle(t)) return
        if (!online()) { speak("Internet yo'q. Hozir faqat telefon buyruqlari ishlaydi."); return }
        val url = prefs.getString("proxy", "") ?: ""
        if (url.isBlank()) { speak("AI server manzili kiritilmagan. Sozlamalarni oching."); return }
        val token = prefs.getString("token", "") ?: ""
        history.add("user" to t); while (history.size > 12) history.removeAt(0)
        val snap = ArrayList(history)
        Thread {
            val r = try { AiClient.ask(url, token, snap) } catch (e: Exception) { null }
            h.post { if (r == null) speak("Serverga ulana olmadim.") else { history.add("model" to r); speak(r) } }
        }.start()
    }

    fun speak(t0: String) {
        val t = t0.replace("*", "").replace("#", "").take(900)
        note("JARVIS: $t"); lastSpoken = t
        if (ttsOk) { speaking = true; tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime()) }
        armTimeout()
    }
    private fun armTimeout() { h.removeCallbacks(timeout); if (conv) h.postDelayed(timeout, 30000) }
    private fun online(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java); val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }
    private fun note(t: String) {
        val line = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + "  " + t
        val all = (line + "\n" + (prefs.getString("log", "") ?: "")).lines().take(50).joinToString("\n")
        prefs.edit().putString("log", all).putString("status", t).apply()
    }
    override fun onDestroy() {
        running = false; h.removeCallbacksAndMessages(null); rec?.destroy(); tts?.shutdown()
        prefs.edit().putBoolean("live", false).apply(); super.onDestroy()
    }
    override fun onBind(i: Intent?): IBinder? = null
}
