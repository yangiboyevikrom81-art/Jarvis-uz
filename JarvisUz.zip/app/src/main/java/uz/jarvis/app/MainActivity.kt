package uz.jarvis.app

import android.Manifest
import android.animation.ObjectAnimator
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView; private lateinit var log: TextView
    private lateinit var orb: View; private lateinit var mic: Button; private lateinit var input: EditText
    private lateinit var prefs: SharedPreferences
    private val PICK = 11
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> refresh() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        status = findViewById(R.id.status); log = findViewById(R.id.log); orb = findViewById(R.id.orb); mic = findViewById(R.id.mic); input = findViewById(R.id.input)
        ObjectAnimator.ofFloat(orb, "scaleX", 1f, 1.12f).apply { duration = 1200; repeatMode = ObjectAnimator.REVERSE; repeatCount = -1; start() }
        ObjectAnimator.ofFloat(orb, "scaleY", 1f, 1.12f).apply { duration = 1200; repeatMode = ObjectAnimator.REVERSE; repeatCount = -1; start() }
        mic.setOnClickListener { toggleLive() }
        findViewById<Button>(R.id.btnApps).setOnClickListener { chooseApps() }
        findViewById<Button>(R.id.btnPerm).setOnClickListener { showPermissions() }
        findViewById<Button>(R.id.btnFile).setOnClickListener { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), PICK) }
        findViewById<Button>(R.id.btnSet).setOnClickListener { settingsDialog() }
        input.setOnEditorActionListener { _, _, _ ->
            val t = input.text.toString(); input.setText("")
            if (t.isNotBlank() && hasPerms()) ContextCompat.startForegroundService(this, Intent(this, LiveService::class.java).setAction("TEXT").putExtra("t", t)) else askPerms()
            true }
        prefs.registerOnSharedPreferenceChangeListener(listener); refresh()
    }
    override fun onDestroy() { prefs.unregisterOnSharedPreferenceChangeListener(listener); super.onDestroy() }

    private fun refresh() {
        val live = prefs.getBoolean("live", false)
        mic.text = if (live) "⏹ SUHBATNI TO'XTATISH" else "🎤 UZLUKSIZ SUHBATNI BOSHLASH"
        orb.alpha = if (live) 1f else 0.5f
        status.text = if (live) "🎤 Eshitaman — \"JARVIS\" deb chaqiring" else prefs.getString("status", "Tayyor.")
        log.text = prefs.getString("log", "")
    }
    private fun hasPerms() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun askPerms() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }
    private fun toggleLive() {
        if (prefs.getBoolean("live", false)) { startService(Intent(this, LiveService::class.java).setAction("STOP")); return }
        if (!hasPerms()) { askPerms(); return }
        ContextCompat.startForegroundService(this, Intent(this, LiveService::class.java))
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) { if (c == 1 && hasPerms()) toggleLive() }

    private fun chooseApps() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(i, 0).map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }.sortedBy { it.first.lowercase() }
        val sel = (prefs.getStringSet("allowed", emptySet()) ?: emptySet()).toMutableSet()
        AlertDialog.Builder(this).setTitle("Boshqarishga ruxsat")
            .setMultiChoiceItems(apps.map { it.first }.toTypedArray(), BooleanArray(apps.size) { apps[it].second in sel }) { _, k, on -> if (on) sel.add(apps[k].second) else sel.remove(apps[k].second) }
            .setPositiveButton("Saqlash") { _, _ -> prefs.edit().putStringSet("allowed", sel).apply() }.setNegativeButton("Bekor", null).show()
    }
    private fun showPermissions() {
        val msg = "Mikrofon: ${if (hasPerms()) "BOR" else "YO'Q"}\nMaxsus imkoniyatlar: ${if (JarvisAccessibilityService.instance != null) "YOQILGAN" else "O'CHIQ"}\nBoshqa ilovalar ustida ko'rsatish: ${if (Settings.canDrawOverlays(this)) "BOR" else "YO'Q"}\nRuxsat berilgan ilovalar: ${(prefs.getStringSet("allowed", emptySet()) ?: emptySet()).size}\n\nOxirgi ruxsat ekran o'chiq/fonda ilova ochish uchun kerak."
        AlertDialog.Builder(this).setTitle("Ruxsatlar").setMessage(msg)
            .setPositiveButton("Maxsus imkoniyatlar") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNeutralButton("Ustida ko'rsatish") { _, _ -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
            .setNegativeButton("Mikrofon") { _, _ -> askPerms() }.show()
    }
    private fun settingsDialog() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
        val u = EditText(this).apply { hint = "Server manzili (https://...)"; setText(prefs.getString("proxy", "")) }
        val t = EditText(this).apply { hint = "Maxfiy token (APP_TOKEN)"; setText(prefs.getString("token", "")) }
        l.addView(u); l.addView(t)
        AlertDialog.Builder(this).setTitle("AI server").setView(l)
            .setPositiveButton("Saqlash") { _, _ -> prefs.edit().putString("proxy", u.text.toString().trim()).putString("token", t.text.toString().trim()).apply() }.show()
    }
    @Deprecated("ok") override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == PICK && c == RESULT_OK && d?.data != null) try { startActivity(Intent(Intent.ACTION_VIEW).setData(d.data).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        catch (e: Exception) { Toast.makeText(this, "Bu faylni ochadigan ilova yo'q", Toast.LENGTH_LONG).show() }
    }
}
