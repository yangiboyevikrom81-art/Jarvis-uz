// Cloudflare Worker (telefon brauzerida yaratiladi). Sozlamalarda 2 ta Secret: GEMINI_KEY va APP_TOKEN
export default {
  async fetch(req, env) {
    if (req.method !== "POST") return new Response("ok");
    if (req.headers.get("X-App-Token") !== env.APP_TOKEN) return new Response("no", { status: 401 });
    const { messages } = await req.json();
    const body = {
      systemInstruction: { parts: [{ text: "Sen JARVIS, o'zbek tilida gapiradigan ovozli yordamchisan. Faqat o'zbek tilida (lotin yozuvi) javob ber. Javob qisqa (1-3 gap) va og'zaki nutqqa mos bo'lsin; markdown, ro'yxat va emoji ishlatma. Yangi yoki o'zgaruvchan ma'lumot kerak bo'lsa, qidiruvdan foydalan." }] },
      contents: messages.slice(-12).map(m => ({ role: m.role === "user" ? "user" : "model", parts: [{ text: m.text }] })),
      tools: [{ google_search: {} }]
    };
    const model = env.MODEL || "gemini-2.5-flash";
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_KEY }, body: JSON.stringify(body) });
    if (!r.ok) return new Response(await r.text(), { status: 502 });
    const j = await r.json();
    const reply = (j.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("").trim() || "Javob topa olmadim.";
    return Response.json({ reply });
  }
};
